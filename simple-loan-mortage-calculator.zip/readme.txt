===  Simple Loan and Mortgage Calculator ===
Contributors: giannisdallas
Donate link: https://www.paypal.me/IDallas
Tags: loan, calculator, shortcode, widget, mortgage, chart, amortization, amortization schedule
Requires at least:
Tested up to: 4.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Simple Loan and Mortgage Calculator generates a report on the payment of any loan or mortgage.<br>

The user can select the amount, the interest and the repayment period and the calculator generates the report and the amortization schedule chart .<br>

To add the calculator to a page or widget just use [simplelmc]<br>

<em>I would love to hear your feedback. Go ahead and propose ways to make this plugin even better.</em>

Thank you

== Frequently Asked Questions ==

= What  settings are there? =

You can pick the title and the currency. You can select to hide the Amortization Schedule chart

== Upgrade Notice ==

== Screenshots ==

== Changelog ==

version 1.0.0 : first version of the plugin

== Installation ==

<p>1. Upload and extract the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.</p>
<p>2. Activate the plugin through the 'Plugins' screen in WordPress</p>


